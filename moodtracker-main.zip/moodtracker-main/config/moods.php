<?php

return [
    'options' => [
        '🤩 Sangat Senang',
        '😄 Senang',
        '😐 Netral',
        '😔 Kurang Semangat',
        '😢 Depresi',
    ],
];
